package junit;
import java.io.IOException;

import org.junit.Test;

import junit.framework.Assert;
import validate_transaction.*;
public class junit_testing {
	 pollFile p=new pollFile();
	 valid_amount amount=new valid_amount();;
	    valid_date date=new valid_date();
	    valid_payeeAccount payeeAccount=new valid_payeeAccount();
        valid_payeeName payeeName=new valid_payeeName();;
	    valid_payerAccount payerAccount=new valid_payerAccount();
	    valid_payerName payerName=new valid_payerName();
	    valid_transaction_id transaction_id=new valid_transaction_id();
	    @Test
		public void check_date() throws IOException
		{
			String input="12345678901224042019VickeyMickey                       20000102011KamleshPatel                       200001020099      9999.90";
			boolean expected=true;
			boolean output=date.check_date(input);
			System.out.println(output);
			Assert.assertEquals(expected, output);
			
		}
	    @Test
		public void check_negative_amount() throws IOException{
			String input="12345678901217032019VickeyMickey                       20000102011KamleshPatel                       200001020099      -9999.90";
			boolean expected=false;
			boolean actual=amount.check_amount(input);
			System.out.println(actual);
			Assert.assertEquals(expected, actual);
		}
	    @Test
		public void check_payername() throws IOException{
			String input="12345678901217032019Vi#keyMickey                       20000102011KamleshPatel                       200001020099      -9999.90";
			boolean expected=false;
			boolean actual=payerName.check_payername(input);
			Assert.assertEquals(expected, actual);
		}
		@Test
		public void check_payeraccount() throws IOException{
			String input="12345678901217032019VickeyMickey                       2000010201 KamleshPatel                       200001020099      -9999.90";
			boolean expected=false;
			boolean actual=payerAccount.check_payeraccount(input);
			Assert.assertEquals(expected, actual);
		}
		@Test
		public void check_payeename() throws IOException{
			String input="12345678901217032019VickeyMickey                       20000102011Kam$eshPatel                       200001020099      -9999.90";
			boolean expected=false;
			boolean actual=payeeName.check_payeename(input);
			Assert.assertEquals(expected, actual);
		}
		@Test
		public void check_payeeaccount() throws IOException{
			String input="12345678901217032019VickeyMickey                       20000102011KamleshPatel                       20000102009       -9999.90";
			boolean expected=false;
			boolean actual=payeeAccount.check_payeeaccount(input);
			Assert.assertEquals(expected, actual);
		}
		@Test
		public void check_transaction_id() throws IOException{
			String input="12345678901 17032019VickeyMickey                       2000010201 KamleshPatel                       200001020099      -9999.90";
			boolean expected=false;
			boolean actual=transaction_id.check_transaction_id(input);
			Assert.assertEquals(expected, actual);
		}


}
