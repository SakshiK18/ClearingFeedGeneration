package validate_transaction;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.*;
public class pollFile {
	BufferedReader br = null;
	Scanner obj;
	String input;
	boolean isFileExist=false;
boolean open_file(String input)
	{
		String fileName=input;
		File f = new File(input);
		try{
			obj=new Scanner(new File(fileName));
			
			if(f.exists()==true && input.endsWith(".txt") && !f.canWrite())
			{
				isFileExist=true;
			}
			else
			{
			isFileExist=false;
			}
		}
		catch(Exception e)
				{
			System.out.println("Could not open file");
				}
		return isFileExist;
	}
	void read_file(String input){
	try
	{
		br = new BufferedReader(new FileReader(input));
		String line;
		
		while((input=br.readLine())!=null)
		{
			System.out.println(input);
		}
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			br.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	}
	void close_file(String input)
	{
		obj.close();
	}
}
