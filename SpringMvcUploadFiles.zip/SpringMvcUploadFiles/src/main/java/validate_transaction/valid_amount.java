package validate_transaction;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class valid_amount {
	

	public boolean check_amount(String line) throws IOException
	{
		String input;
		char amount[]=null;
		boolean numeric=true,check=true;
		BufferedReader br = new BufferedReader(new FileReader(line));
		
	        double num=0;
			int count=0;
			boolean valid=false;
			try{
		amount=new char[127-114];
			line.getChars(114, 127,amount, 0);
			//System.out.println(amount);
			}
			catch(StringIndexOutOfBoundsException e)
			{
				System.out.print("");
			}
			int decimalPlaces=0;
			
			
			
			
			String new_amount=new String(amount);	
			String new_amount1=new_amount.replaceAll("\\s", "");
			//System.out.println(new_amount);
				try{
					 num=Double.parseDouble(new_amount1);
					 int integerPlaces = new_amount1.indexOf('.');
						 decimalPlaces = new_amount1.length() - integerPlaces - 1;
						//System.out.println(decimalPlaces);
				}catch (NumberFormatException e) {
			        numeric = false;
			    }
				final String regExp = "[0-9]+([.][0-9]{1,2})?";
				final Pattern pattern = Pattern.compile(regExp);

				
				Matcher matcher = pattern.matcher(new_amount1); 
				valid=matcher.matches();
				

			if(numeric==true && num>=0  && decimalPlaces==2 && valid==true)
			{
		check=true;
			}
			else
			{
				check=false;
			}
		
		
		//}
		return check;
	}
}
