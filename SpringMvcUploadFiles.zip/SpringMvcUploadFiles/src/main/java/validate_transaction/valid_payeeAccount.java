package validate_transaction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class valid_payeeAccount {
	
	public boolean check_payeeaccount(String line) throws IOException
	{
		String input;
		boolean numeric=true,check=true;

		boolean isnonAlphanumeric=false;
		BufferedReader br = new BufferedReader(new FileReader(line));
		//while((line=br.readLine())!=null)
		//{
			char number[]=new char[114-102];
		  line.getChars(102,114, number, 0);
		  String new_number=new String(number);
		// String new_number1=new_number.replaceAll("\\s", "");
		isnonAlphanumeric=new_number.matches("^[a-zA-Z0-9]*$");
		 
		  if(isnonAlphanumeric){
			 
				check=true;
			} else {
				check=false;
			}

			
		//}
		return check;
	}
	
}
