package validate_transaction;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;


 
public class Feed_Generation {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String input="C://upload//Samplefile_TTS.txt";
	    pollFile p=new pollFile();
	    valid_amount amount=new valid_amount();
	    valid_date date=new valid_date();
	    valid_payeeAccount payeeAccount=new valid_payeeAccount();
	    valid_payeeName payeeName=new valid_payeeName();
	    valid_payerAccount payerAccount=new valid_payerAccount();
	    valid_payerName payerName=new valid_payerName();
	    valid_transaction_id transaction_id=new valid_transaction_id();
	    
	    if(p.open_file(input)==true) {
		p.read_file(input);
		String line=input;
		BufferedReader br = new BufferedReader(new FileReader(input));
		File valid = new File("C://upload//Results//Valid.txt");

		if (!valid.exists()) {
		    valid.createNewFile();
		}
		File invalid = new File("C://upload//Results//Invalid.txt");

		if (!invalid.exists()) {
		   invalid.createNewFile();
		}
		FileWriter filewriter1 = new FileWriter(valid.getAbsoluteFile());
		BufferedWriter outputStream1= new BufferedWriter(filewriter1);

		FileWriter filewriter2 = new FileWriter(invalid.getAbsoluteFile());
		BufferedWriter outputStream2= new BufferedWriter(filewriter2);
			while((line=br.readLine())!=null)
			{
		if(transaction_id.check_transaction_id(line)==true && date.check_date(line)==true && payerName.check_payername(line)==true && payerAccount.check_payeraccount(line)==true && payeeName.check_payeename(line)==true && payeeAccount.check_payeeaccount(line)==true && amount.check_amount(line)==true)
		{
			System.out.println("Valid Transaction");
			
			
		 outputStream1.write(line);
		 outputStream1.newLine();
			
		}
		else
		{
			System.out.println("Invalid Transaction");
		 outputStream2.write(line);
		 outputStream2.newLine();

		}
		}
			
			outputStream1.flush();
		    outputStream1.close();
		   
		    outputStream2.flush();
		    outputStream2.close();
		   p.close_file(line);
		  
		    br.close();
	}
	    else
	    {
	    	System.out.print("Could not find file");
	    }
	}

}
