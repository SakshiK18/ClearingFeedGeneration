package validate_transaction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class valid_payerName {
	String line="C:\\FILE\\Samplefile_TTS.txt";
	public void setLine(String line) {
		this.line = line;
	}
	public boolean check_payername(String line) throws IOException{
		String input;
		boolean numeric=true,check=true;

		boolean isnonAlphanumeric=false;
		BufferedReader br = new BufferedReader(new FileReader(line));
		//while((line=br.readLine())!=null)
		//{
			char name[]=new char[55-20];
		  line.getChars(20, 55, name, 0);
		  String new_name=new String(name);
		 String new_name1=new_name.replaceAll("\\s", "");
		isnonAlphanumeric=new_name1.matches("^[a-zA-Z0-9]*$");
		 
		  if(isnonAlphanumeric){
			 
				check=true;
			} else {
				check=false;
			}

			
		//}
		return check;
	}
}
