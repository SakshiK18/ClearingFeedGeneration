package validate_transaction;

import java.util.*;
import java.io.*;
import java.util.regex.*;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.jackrutorial.model.*;
class feed_generation{
	feed_generation(){}
	BufferedReader br = null;
	Scanner obj;
	
	 
	void pollFile(String input)
	{
		
			File f = new File(input);
			try{
				obj=new Scanner(new File(input));
				if(input.endsWith(".txt") && !f.canWrite())
				{
					System.out.println("Valid file");
				}
				else
				{
					System.out.println("Invalid file");
				}
			}
			catch(Exception e)
					{
				System.out.println("Could not find file");
					}
		
		
	}
		void read_file(String input){
			try
			{
				br = new BufferedReader(new FileReader(input));
				String line;
				
				while((line=br.readLine())!=null)
				{
					System.out.println(line);
				}
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					br.close();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
			}
			void close_file()
			{
				obj.close();
			}
			public boolean check_amount(String line) throws IOException
			{
				
				char amount[]=null;
				boolean numeric=true,check=true;
			
				
					double num=0;
					
					boolean valid=false;
					try{
				amount=new char[127-114];
					line.getChars(114, 127,amount, 0);
					
					}
					catch(StringIndexOutOfBoundsException e)
					{
						System.out.print("");
					}
					int decimalPlaces=0;
					
					
					
					
					String new_amount=new String(amount);	
					String new_amount1=new_amount.replaceAll("\\s", "");
					
						try{
							 num=Double.parseDouble(new_amount1);
							 int integerPlaces = new_amount1.indexOf('.');
								 decimalPlaces = new_amount1.length() - integerPlaces - 1;
						
						}catch (NumberFormatException e) {
					        numeric = false;
					    }
						final String regExp = "[0-9]+([.][0-9]{1,2})?";
						final Pattern pattern = Pattern.compile(regExp);

						
						Matcher matcher = pattern.matcher(new_amount1); 
						valid=matcher.matches();
						

					if(numeric==true && num>=0  && decimalPlaces==2 && valid==true)
					{
				check=true;
					}
					else
					{
						check=false;
					}
				
				return check;
			}
			public boolean check_date(String line) throws IOException
			{
				String input;
				boolean numeric=true,check=true;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				
					char date[]=new char[20-12];
					line.getChars(12, 20, date, 0);
					String new_date=new String(date);

					
					DateFormat dtf = new SimpleDateFormat("ddMMYYYY");

					Date now=new Date();
					String date1=dtf.format(now);
					if(date1.equals(new_date))
						{
						check=true;
						}
					else{
						check=false;
				}
				
				return check;
			}
			public boolean check_payeeaccount(String line) throws IOException
			{
				String input;
				boolean numeric=true,check=true;

				boolean isnonAlphanumeric=false;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				
					char number[]=new char[114-102];
				  line.getChars(102,114, number, 0);
				  String new_number=new String(number);
				
				isnonAlphanumeric=new_number.matches("^[a-zA-Z0-9]*$");
				 
				  if(isnonAlphanumeric){
					 
						check=true;
					} else {
						check=false;
					}

					
				
				return check;
			}
			
			public boolean check_payeename(String line) throws IOException
			{
				String input;
				boolean numeric=true,check=true;
				

				boolean isnonAlphanumeric=false;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				
					char name[]=new char[102-67];
				  line.getChars(67, 102, name, 0);
				  String new_name=new String(name);
				 String new_name1=new_name.replaceAll("\\s", "");
				isnonAlphanumeric=new_name1.matches("^[a-zA-Z0-9]*$");
				 
				  if(isnonAlphanumeric){
					 check=true;
						
					} else {
						check=false;
					}

					
				
				return check;
			}
			public boolean check_payeraccount(String line) throws IOException
			{
				String input;
				boolean numeric=true,check=true;

				boolean isnonAlphanumeric=false;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				
					char number[]=new char[67-55];
				  line.getChars(55, 67, number, 0);
				  String new_number=new String(number);
				 
				isnonAlphanumeric=new_number.matches("^[a-zA-Z0-9]*$");
				 
				  if(isnonAlphanumeric){
					 check=true;
						
					} else {
					check=false;
					}

					
				//}
				return check;
			}
			public boolean check_payername(String line) throws IOException{
				String input;
				boolean numeric=true,check=true;

				boolean isnonAlphanumeric=false;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				
					char name[]=new char[55-20];
				  line.getChars(20, 55, name, 0);
				  String new_name=new String(name);
				 String new_name1=new_name.replaceAll("\\s", "");
				isnonAlphanumeric=new_name1.matches("^[a-zA-Z0-9]*$");
				 
				  if(isnonAlphanumeric){
					 
						check=true;
					} else {
						check=false;
					}

					
				
				return check;
			}
			ArrayList<String> transactionId=new ArrayList();
			Set<String> t= new HashSet();
			public boolean check_transaction_id(String line) throws IOException
			{
				String input;
				long num=0;
				boolean numeric=true,check=false;
				BufferedReader br = new BufferedReader(new FileReader("C:\\FILE\\Samplefile_TTS.txt"));
				//while((line=br.readLine())!=null)
				//{
					
					char tran_id[]=new char[12-0];
					line.getChars(0, 12, tran_id, 0);
					//System.out.println(tran_id);
					String new_id=new String(tran_id);	
						try{
							 num=Long.parseLong(new_id);
						}catch (NumberFormatException e) {
					        numeric = false;
					    }

						boolean flag=check_unique_transaction_id(new_id);
					if(numeric==true && flag==true)
					{
						check=true;
					}
					else
					{
						
					}
		
				return check;
			}
			boolean check_unique_transaction_id(String new_id) throws IOException
			{
				boolean check=false;
				
			
					if(transactionId.contains(new_id)==false)
					{
						transactionId.add(new_id);
						check=true;
					}
					else{
						check=false;
					}
				
				
				return check;
			}

}
public class Application {

	public static void main(String[] args) throws IOException {
		
	
		String input="C://upload//Samplefile_TTS.txt";
feed_generation f=new feed_generation();
f.pollFile(input);
f.read_file(input);
String line;
BufferedReader br = new BufferedReader(new FileReader(input));
File valid = new File("C://upload//Results//Valid.txt");

if (!valid.exists()) {
    valid.createNewFile();
}
File invalid = new File("C://upload//Results//Invalid.txt");

if (!invalid.exists()) {
   invalid.createNewFile();
}
FileWriter filewriter1 = new FileWriter(valid.getAbsoluteFile());
BufferedWriter outputStream1= new BufferedWriter(filewriter1);

FileWriter filewriter2 = new FileWriter(invalid.getAbsoluteFile());
BufferedWriter outputStream2= new BufferedWriter(filewriter2);
	while((line=br.readLine())!=null)
	{
if(f.check_transaction_id(line)==true && f.check_date(line)==true && f.check_payername(line)==true && f.check_payeraccount(line)==true && f.check_payeename(line)==true && f.check_payeeaccount(line)==true && f.check_amount(line)==true)
{
	System.out.println("Valid Transaction");
	
	
 outputStream1.write(line);
 outputStream1.newLine();
	
}
else
{
	System.out.println("Invalid Transaction");
 outputStream2.write(line);
 outputStream2.newLine();

}
}
	outputStream1.flush();
    outputStream1.close();
    outputStream2.flush();
    outputStream2.close();
    f.close_file();
    br.close();
	}

}
