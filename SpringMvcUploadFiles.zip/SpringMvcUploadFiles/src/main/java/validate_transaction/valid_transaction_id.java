package validate_transaction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class valid_transaction_id {
	
	
	ArrayList<String> transactionId=new ArrayList();
	Set<String> t= new HashSet();
	public boolean check_transaction_id(String line) throws IOException
	{
		
		long num=0;
		boolean numeric=true,check=false;
		BufferedReader br = new BufferedReader(new FileReader(line));
		//while((line=br.readLine())!=null)
		//{
			
			char tran_id[]=new char[12-0];
			line.getChars(0, 12, tran_id, 0);
			//System.out.println(tran_id);
			String new_id=new String(tran_id);	
				try{
					 num=Long.parseLong(new_id);
				}catch (NumberFormatException e) {
			        numeric = false;
			    }

				boolean flag=check_unique_transaction_id(new_id);
			if(numeric==true && flag==true)
			{
				check=true;
			}
			else
			{
				
			}
//transactionId.add(new_id);


		//}
		return check;
	}
	boolean check_unique_transaction_id(String new_id) throws IOException
	{
		boolean check=false;
		
		//boolean flag=check_transaction_id();
		//for(String s:transactionId)
		//{
			if(transactionId.contains(new_id)==false)
			{
				transactionId.add(new_id);
				check=true;
			}
			else{
				check=false;
			}
		//}
		
		return check;
	}
}
