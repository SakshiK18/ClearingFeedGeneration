package validate_transaction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class valid_date {
	

	public boolean check_date(String line) throws IOException
	{
		String input;
		boolean numeric=true,check=true;
		BufferedReader br = new BufferedReader(new FileReader(line));
		//while((line=br.readLine())!=null)
		//{
			char date[]=new char[20-12];
			line.getChars(12, 20, date, 0);
			String new_date=new String(date);

			//System.out.println(new_date);
			DateFormat dtf = new SimpleDateFormat("ddMMYYYY");

			Date now=new Date();
			String date1=dtf.format(now);
			if(date1.equals(new_date))
				{
				check=true;
				}
			else{
				check=false;
		}
		//}
		return check;
	}
}
