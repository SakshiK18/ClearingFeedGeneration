package validate_transaction;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class valid_payeeName {
	

	public boolean check_payeename(String line) throws IOException
	{
		String input;
		boolean numeric=true,check=true;
		

		boolean isnonAlphanumeric=false;
		BufferedReader br = new BufferedReader(new FileReader(line));
		//while((line=br.readLine())!=null)
		//{
			char name[]=new char[102-67];
		  line.getChars(67, 102, name, 0);
		  String new_name=new String(name);
		 String new_name1=new_name.replaceAll("\\s", "");
		isnonAlphanumeric=new_name1.matches("^[a-zA-Z0-9]*$");
		 
		  if(isnonAlphanumeric){
			 check=true;
				
			} else {
				check=false;
			}

			
		//}
		return check;
	}
}
